frame_width = 1344
frame_height = 756
time_limit = 120

game_loop_delay_time = 50

food_colors = ['./material/meat.png', './material/tomato.png', './material/bread.png', './material/hamburger.png']
food_width = [46, 46, 52, 42]
food_height = [24, 24, 30, 36]

cook_source = ['./material/Cook Lin.png', './material/Cook Chen.png']
char_width = 54
char_height = 74
char_speed = 7

# Show shadows of brick, kitchen, and counter or not
shadow_exist_bg = False
shadow_bg = 'black' if shadow_exist_bg else ''

head_width = 62
head_height = 58
head_source = ['./material/Cook Lin head.png', './material/Cook Chen head.png']