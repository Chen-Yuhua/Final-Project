from PIL import Image, ImageTk
from GameObject import MyGameObject
from brick import MyBrick
from kitchen import MyKitchen, MyKitchenShadow
from counter import MyCounter
from food import MyFood
import constants as csts

class MyChar(MyGameObject): 
    def __init__(self, canvas, x, y, who):
        self.width = csts.char_width
        self.height = csts.char_height
        self.food = None
        self.take_food = False
        self.release = True
        self.img = Image.open(csts.cook_source[who])
        self.tk_img = ImageTk.PhotoImage(self.img.resize((self.width, self.height)))
        item = canvas.create_image(x - self.width / 2, y - self.height / 2, anchor='nw', image=self.tk_img)
        self.shadow = MyShadow(canvas, self, x, y, self.width, self.height)
        super(MyChar, self).__init__(canvas, item)

    def addFood(self, food_type):
        coords = self.position()
        x = coords[0] + self.width * 0.45
        y = coords[1] + self.height * 0.75

        self.food = MyFood(self.canvas, x, y, food_type)
        self.take_food = True
    
    def get_dish(self, dish):
        self.food = dish
        coords = self.position()
        x = coords[0] + self.width * 0.1
        y = coords[1] + self.height * 0.6
        dish.moveto(x, y)
        self.take_food = True

    def giveup_food(self):
        self.food = None
        self.take_food = False
    
    def deleteFood(self):
        self.food.delete()
        self.giveup_food()

    def move(self, x, y):  # x and y are the distances you want to move
        coords = self.position()
        width = self.canvas.winfo_width()
        super(MyChar, self).move(x, y)
        if self.food is not None:
            self.food.move(x, y)
    
    def delete(self):
        if self.food: 
            self.food.delete()
        super(MyChar, self).delete()

class MyShadow(MyGameObject):
    def __init__(self, canvas, master, x, y, width, height):
        self.width = width
        self.height = height
        self.master = master
        item = canvas.create_rectangle(x - self.width / 2, y - self.height / 2,x + self.width / 2,y + self.height / 2, fill='', outline='')
        super(MyShadow, self).__init__(canvas, item)
    
    def move(self, x, y, items):  # x and y are the distances you want to move
        coords = self.position()
        width = self.canvas.winfo_width()
        height = self.canvas.winfo_height()

        collide_items = self.canvas.find_overlapping(*self.position())  # return whether the shadow collide with sth
        collide_kitchenShadows = [items[x] for x in collide_items if x in items and isinstance(items[x], MyKitchenShadow)]

        if coords[0] + x >= 0 and coords[2] + x <= width and coords[1] + y >= 0 and coords[3] + y <= height:  # make sure it doesn't go outside the canvas
            super(MyShadow, self).move(x, y)  # move the shadow first to make sure it's safe
            if not self.collide(items):
                self.master.move(x, y)  # move the character
                collide_items = self.canvas.find_overlapping(*self.position())
                collide_kitchenShadows_after = [items[x] for x in collide_items if x in items and isinstance(items[x], MyKitchenShadow)]
                if len(collide_kitchenShadows_after) < len(collide_kitchenShadows):  # leaving kitchen
                    collide_kitchenShadows[0].master.stop_kitchen(self.master)
            else:
                super(MyShadow, self).move(-x, -y)  # move the shadow back
    
    def update_position(self, direction, items):
        speed = csts.char_speed
        match direction:
            case '1':
                self.move(-speed, -speed, items)
            case '2':
                self.move(0, -speed, items)
            case '3':
                self.move(speed, -speed, items)
            case '4':
                self.move(-speed, 0, items)
            case '6':
                self.move(speed, 0, items)
            case '7':
                self.move(-speed, speed, items)
            case '8':
                self.move(0, speed, items)
            case '9':
                self.move(speed, speed, items)
    
    def collide(self, items):
        collide_items = self.canvas.find_overlapping(*self.position())  # return whether the shadow collide with sth
        game_objects = [items[x] for x in collide_items if x in items and (isinstance(items[x], MyBrick) or isinstance(items[x], MyKitchen) or isinstance(items[x], MyCounter))]
        if len(game_objects) >= 1:  # There is a collision
            print("Collide!")
            return True
    
class MyCharHead(MyGameObject): 
    def __init__(self, canvas, x, y, who):
        self.width = csts.head_width
        self.height = csts.head_height
        self.img = Image.open(csts.head_source[who])
        self.tk_img = ImageTk.PhotoImage(self.img.resize((self.width, self.height)))
        item = canvas.create_image(x - self.width / 2, y - self.height / 2, anchor='nw', image=self.tk_img)
        super(MyCharHead, self).__init__(canvas, item)