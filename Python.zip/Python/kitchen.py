from GameObject import MyGameObject
from food import MyFood
import constants as csts

class MyKitchen(MyGameObject):
    def __init__(self, canvas, x, y):
        self.width = 413
        self.height = 145
        self.food = []
        self.used = False
        self.placing = None
        self.start_cooking_time = None
        self.dish_done = False
        item = canvas.create_rectangle(x - self.width / 2, y - self.height / 2, x + self.width / 2,y + self.height / 2, 
                                        fill='', outline='', tags='kitchen')
        super(MyKitchen, self).__init__(canvas, item)
    
    def stop_kitchen(self, char):
        self.start_cooking_time = None
        if self.used == True:
            print("Stop using kitchen!")
            if self.dish_done:
                print("Take dish! ")
                char.get_dish(self.container.food[0])
                self.container.food = []
                self.dish_done = False
            elif self.placing > 0 and char.food is not None:
                print("Place a item!")
                self.container.addFood(char.food)
                char.giveup_food()
            self.shadow.deleteProgressBar()
            self.used = False
    
    def delete(self):
        self.container.delete()
        self.shadow.delete()
        super(MyKitchen, self).delete()

class MyKitchenShadow(MyGameObject):
    def __init__(self, canvas, x, y):
        self.width = 45
        self.height = 45
        self.progress_bars = []
        self.progress_bar_size = 10
        self.x = x
        self.y = y
        self.canvas = canvas
        item = canvas.create_rectangle(x - self.width / 2, y - self.height / 2, x + self.width / 2,y + self.height / 2, 
                                        fill='', outline = csts.shadow_bg, tags='kitchenShadow')
        super(MyKitchenShadow, self).__init__(canvas, item)
    
    def addProgressBar(self, num):
        x = self.x + 30
        y = self.y - 30
        for i in range(len(self.progress_bars), num):
            item = self.canvas.create_rectangle(x - self.progress_bar_size / 2 + i * self.progress_bar_size, y - self.progress_bar_size / 2, x + self.progress_bar_size / 2 + i * self.progress_bar_size, y + self.progress_bar_size / 2, 
                                        fill='green', tags='progressBar')
            self.progress_bars.append(item)
    
    def deleteProgressBar(self):
        while(len(self.progress_bars) > 0):
            self.canvas.delete(self.progress_bars[-1])
            self.progress_bars = self.progress_bars[:-1]

class MyKitchenContainer(MyGameObject):
    def __init__(self, canvas, x, y, master):
        self.x = x
        self.y = y
        self.master = master
        self.width = 160
        self.height = 60
        self.food = []
        self.food_placement = [[0], [-35, 35], [-50, 0, 50]]
        item = canvas.create_rectangle(x - self.width / 2, y - self.height / 2, x + self.width / 2,y + self.height / 2, 
                                        fill='', tags='kitchenContainer')
        super(MyKitchenContainer, self).__init__(canvas, item)
    
    def addFood(self, food):
        self.food.append(food)
        num = len(self.food)
        for i in range(num):
            self.food[i].moveto(self.x - self.food[i].width / 2 + self.food_placement[num - 1][i], self.y - self.food[i].height / 2)
    
    def clear(self):
        for f in self.food:
            f.delete()
        self.food = []
    
    def done_cooking(self, canvas): 
        colors = [f.color for f in self.food]
        if 0 in colors and 1 in colors and 2 in colors: 
            print("Create dish! ")
            self.clear()
            dish = MyFood(canvas, self.x, self.y, 3)
            self.master.dish_done = True
            self.addFood(dish)
    
    def delete(self):
        for f in self.food: 
            f.delete()
        super(MyKitchenContainer, self).delete()