from PIL import Image, ImageTk
from GameObject import MyGameObject
import constants as csts

class MyFood(MyGameObject):
    def __init__(self, canvas, x, y, color):
        COLORS = csts.food_colors
        self.width = csts.food_width[color]
        self.height = csts.food_height[color]
        self.color = color
        self.img = Image.open(COLORS[color])
        self.tk_img = ImageTk.PhotoImage(self.img.resize((self.width, self.height)))
        item = canvas.create_image(x - self.width / 2, y - self.height / 2, anchor='nw', image=self.tk_img)
        # item = canvas.create_oval(x-self.radius, y-self.radius, x+self.radius, y+self.radius,fill=COLORS[color])
        super(MyFood, self).__init__(canvas, item)