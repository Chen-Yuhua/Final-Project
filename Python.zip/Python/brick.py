from GameObject import MyGameObject
import constants as csts

class MyBrick(MyGameObject):
    # COLORS = ['#aaaaaa', '#888888']

    def __init__(self, canvas, x, y):
        self.width = 110
        self.height = 110
        # self.color = MyBrick.COLORS[color]
        item = canvas.create_rectangle(x - self.width / 2, y - self.height / 2, x + self.width / 2,y + self.height / 2, 
                                        fill='', outline='', tags='brick')
        super(ＭyBrick, self).__init__(canvas, item)

class MyBrickShadow(MyGameObject):
    def __init__(self, canvas, x, y, food_type):
        self.width = 45
        self.height = 45
        self.food_type = food_type
        item = canvas.create_rectangle(x - self.width / 2, y - self.height / 2, x + self.width / 2,y + self.height / 2, 
                                        fill='', outline = csts.shadow_bg, tags='brickShadow')
        super(MyBrickShadow, self).__init__(canvas, item)