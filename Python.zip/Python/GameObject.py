class MyGameObject(object):  # kinda like the template for all objects
    def __init__(self, mycanvas, item):
        self.canvas = mycanvas
        self.item = item

    def position(self):
        # print(self.item, self.canvas.coords(self.item))
        return self.canvas.coords(self.item)

    def move(self, c_x, c_y):
        self.canvas.move(self.item, c_x, c_y)
    
    def moveto(self, c_x, c_y):
        self.canvas.moveto(self.item, c_x, c_y)

    def delete(self):
        self.canvas.delete(self.item)