from GameObject import MyGameObject
import constants as csts

class MyCounter(MyGameObject):

    def __init__(self, canvas, x, y):
        self.width = 150
        self.height = 125
        item = canvas.create_rectangle(x - self.width / 2, y - self.height / 2, x + self.width / 2, y + self.height / 2, 
                                        fill='', outline='', tags='counter')
        super(MyCounter, self).__init__(canvas, item)

class MyCounterShadow(MyGameObject):
    def __init__(self, canvas, x, y):
        self.width = 45
        self.height = 45
        item = canvas.create_rectangle(x - self.width / 2, y - self.height / 2, x + self.width / 2, y + self.height / 2, 
                                        fill='', outline = csts.shadow_bg, tags='counterShadow')
        super(MyCounterShadow, self).__init__(canvas, item)