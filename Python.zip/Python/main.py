from tkinter import *
from PIL import Image, ImageTk
import time
import socket

from GameObject import MyGameObject
from char import MyShadow, MyChar, MyCharHead
from brick import MyBrick, MyBrickShadow
from kitchen import MyKitchen, MyKitchenShadow, MyKitchenContainer
from counter import MyCounter, MyCounterShadow
import constants as csts

control_mode = 2  # 1 for keyboard, 2 for joystick

class MyButton(MyGameObject):
    def __init__(self, canvas, x, y, text):
        self.width = 230
        self.height = 80
        item = canvas.create_rectangle(x - self.width / 2, y - self.height / 2, x + self.width / 2,y + self.height / 2, 
                                        fill='', tags='button')
        self.text = canvas.create_text(x, y, text=text, font=('Times New Roman', 25))
        super(MyButton, self).__init__(canvas, item)
    
    def delete(self, canvas):
        canvas.delete(self.text)
        super(MyButton, self).delete()

class MyGame(Frame):
    def __init__(self):
        master = Tk()  # the window
        master.title('Overcooked!')  # the title on top of window
        super(MyGame, self).__init__(master)  # parameter in super() means: in all ancestors of "self", 
                                              # super() return the father of datatype "MyGame", in this case "Frame"
                                              # init of Frame requires a window
        self.time_limit = csts.time_limit
        self.width = csts.frame_width
        self.height = csts.frame_height
        self.canvas = Canvas(self, width=self.width, height=self.height)
        self.img = Image.open('./material/game background.jpg')
        self.tk_img = ImageTk.PhotoImage(self.img.resize((self.width, self.height)))
        self.canvas.create_image(0, 0, anchor='nw', image=self.tk_img)

        self.canvas.pack()
        self.pack()  # pack the frame to the window
        self.items = {}
        
        self.hud = None  # head-up display, the text displaying remaining time
        self.gamemode = True
        self.score = [0, 0]
        self.setupGame()
        self.canvas.focus_set()  # focus on this canvas

    def connectWifi(self):
        bind_ip = socket.gethostbyname(socket.gethostname())
        bind_port = 9999
        server = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
        server.bind((bind_ip,bind_port))
        server.listen()
        print("Listening on", bind_ip, ":", bind_port)

        self.client, addr = server.accept()
        print ("Connected to", addr)

    def set_gamemode(self, gamemode): 
        self.gamemode = gamemode

    def setupGame(self):
        if control_mode == 2: 
            self.connectWifi()
        self.title = self.draw_text(self.width / 2, self.height / 2 - 160, 'Crazy Kitchen', 40)
        self.button1 = self.addButton(self.width / 2, self.height / 2 - 50, "V.S. Mode")
        self.button2 = self.addButton(self.width / 2, self.height / 2 + 70, "Team Mode")
        if control_mode == 1:
            self.text = self.draw_text(self.width / 2, self.height / 2 + 170, 'Press "SPACE" to start the game', 20)
            self.canvas.bind('<space>', lambda _: self.start_game())
            self.canvas.bind('1', lambda _: self.set_gamemode(True))
            self.canvas.bind('2', lambda _: self.set_gamemode(False))
        if control_mode == 2: 
            self.text = self.draw_text(self.width / 2, self.height / 2 + 170, 'Press black button to start the game', 20)
            self.setupGameloop()
    
    def setupGameloop(self):
        data = self.client.recv(1024).decode('utf-8')
        if data[1] == '1':
            self.gamemode = True
        if data[3] == '1':
            self.gamemode = False
        if data[4] == '1':
            self.start_game()
        else:
            self.after(csts.game_loop_delay_time, self.setupGameloop)

    def addButton(self, x, y, text):
        button = MyButton(self.canvas, x, y, text)
        self.items[button.item] = button
        return button
    
    def addBrick(self, x, y):
        brick = MyBrick(self.canvas, x, y)
        self.items[brick.item] = brick
    
    def addBrickShadow(self, x, y, type):
        brick_shadow = MyBrickShadow(self.canvas, x, y, type)
        self.items[brick_shadow.item] = brick_shadow
    
    def addKitchen(self, x, y, up_or_down):
        kitchen = MyKitchen(self.canvas, x, y)
        if up_or_down: 
            kitchen_shadow = MyKitchenShadow(self.canvas, x, y - 110)
            kitchen_container = MyKitchenContainer(self.canvas, x + 160, y - 120, kitchen)
        else:
            kitchen_shadow = MyKitchenShadow(self.canvas, x, y + 110)
            kitchen_container = MyKitchenContainer(self.canvas, x + 160, y + 120, kitchen)
        
        self.items[kitchen.item] = kitchen
        self.items[kitchen_shadow.item] = kitchen_shadow
        self.items[kitchen_container.item] = kitchen_container
        kitchen.shadow = kitchen_shadow
        kitchen.container = kitchen_container
        kitchen_shadow.master = kitchen
        self.kitchen.append(kitchen)
    
    def addCounter(self, x, y):
        counter = MyCounter(self.canvas, x, y)
        self.items[counter.item] = counter
        counter_shadow = MyCounterShadow(self.canvas, x - 120, y)
        self.items[counter_shadow.item] = counter_shadow

    def draw_text(self, x, y, text, size='55'):
        font = ('Times New Roman', size)
        return self.canvas.create_text(x, y, text=text, font=font)

    def update_time_text(self, remain_time): 
        text = 'Time: %s' % remain_time
        if self.hud is None:
            self.hud = self.draw_text(1230, 40, text, 35)
        else:
            self.canvas.itemconfig(self.hud, text=text)
    
    def take_food(self, who):
        collide_items = self.canvas.find_overlapping(*self.char[who].shadow.position())
        collide_brickShadow = [self.items[x] for x in collide_items if x in self.items and isinstance(self.items[x], MyBrickShadow)]

        if len(collide_brickShadow) >= 1 and self.char[who].release: 
            if self.char[who].take_food == False:
                print("Take food!")
                self.char[who].addFood(collide_brickShadow[0].food_type)
                self.char[who].release = False
            else:
                print("Put down food!")
                self.char[who].deleteFood()
                self.char[who].release = False
    
    def use_kitchen(self, who):
        collide_items = self.canvas.find_overlapping(*self.char[who].shadow.position())
        collide_kitchenShadow = [self.items[x] for x in collide_items if x in self.items and isinstance(self.items[x], MyKitchenShadow)]

        if len(collide_kitchenShadow) >= 1 and self.char[who].release: 
            kitchen_shadow = collide_kitchenShadow[0]
            kitchen = kitchen_shadow.master
            if kitchen.used == False:
                print("Use kitchen!")
                kitchen.used = True
                kitchen.placing = 5
            elif kitchen.placing != 0:
                kitchen.placing -= 1
            elif kitchen.placing == 0 and kitchen.start_cooking_time == None:
                print("Start cooking!")
                kitchen.start_cooking_time = time.time()
                kitchen_shadow.addProgressBar(1)
            else:
                cooked_time = time.time() - kitchen.start_cooking_time
                if len(kitchen_shadow.progress_bars) < cooked_time*2:
                    kitchen_shadow.addProgressBar(int(cooked_time*2))
                if len(kitchen_shadow.progress_bars) >= 10:
                    print("Done cooking!")
                    kitchen.container.done_cooking(self.canvas)
                    kitchen.used = False
                    kitchen_shadow.deleteProgressBar()
                    kitchen.start_cooking_time = None
                    self.char[who].release = False

    def stop_using_kitchen(self, who):
        collide_items = self.canvas.find_overlapping(*self.char[who].shadow.position())
        collide_kitchenShadow = [self.items[x] for x in collide_items if x in self.items and isinstance(self.items[x], MyKitchenShadow)]

        if len(collide_kitchenShadow) >= 1: 
            kitchen_shadow = collide_kitchenShadow[0]
            kitchen = kitchen_shadow.master
            kitchen.stop_kitchen(self.char[who])
        
        self.char[who].release = True
    
    def send_meal(self, who):
        collide_items = self.canvas.find_overlapping(*self.char[who].shadow.position())
        collide_counterShadow = [self.items[x] for x in collide_items if x in self.items and isinstance(self.items[x], MyCounterShadow)]

        if len(collide_counterShadow) >= 1: 
            if self.char[who].take_food == True:
                print("Send meal!")
                self.char[who].deleteFood()
                self.add_score(who, 1)
                self.char[who].release = False
    
    def add_score(self, who, num):
        if not self.gamemode: 
            who = 0
        self.score[who] += num
        text = ': %s' % self.score[who]
        if who == 0:
            self.canvas.itemconfig(self.score_display1, text=text)
        elif who == 1:
            self.canvas.itemconfig(self.score_display2, text=text)

    def bind(self):
        self.canvas.bind('a' , lambda _: self.char[0].shadow.move(-20,   0, self.items))
        self.canvas.bind('d', lambda _: self.char[0].shadow.move( 20,   0, self.items))
        self.canvas.bind('w'   , lambda _: self.char[0].shadow.move(  0, -20, self.items))
        self.canvas.bind('s' , lambda _: self.char[0].shadow.move(  0,  20, self.items))
        self.canvas.bind('<Control_L>' , lambda _: self.take_food(0))
        self.canvas.bind('z', lambda _: self.use_kitchen(0))
        self.canvas.bind('x', lambda _: self.stop_using_kitchen(0))
        self.canvas.bind('c', lambda _: self.send_meal(0))

        self.canvas.bind('<Left>' , lambda _: self.char[1].shadow.move(-20,   0, self.items))
        self.canvas.bind('<Right>', lambda _: self.char[1].shadow.move( 20,   0, self.items))
        self.canvas.bind('<Up>'   , lambda _: self.char[1].shadow.move(  0, -20, self.items))
        self.canvas.bind('<Down>' , lambda _: self.char[1].shadow.move(  0,  20, self.items))
        self.canvas.bind('<Control_R>' , lambda _: self.take_food(1))
        self.canvas.bind(',', lambda _: self.use_kitchen(1))
        self.canvas.bind('.', lambda _: self.stop_using_kitchen(1))
        self.canvas.bind('/', lambda _: self.send_meal(1))
    
    def pause(self):
        if not self.pause_release: 
            return

        if self.paused:  # continue playing
            self.start_time = time.time()
            self.paused = False
            if control_mode == 1:
                self.bind()
            self.pause_release = False
        else:  # pause
            self.accum_time += time.time() - self.start_time
            self.paused = True
            if control_mode == 1:
                self.canvas.unbind('<Left>')
                self.canvas.unbind('<Right>')
                self.canvas.unbind('<Up>')
                self.canvas.unbind('<Down>')
                self.canvas.unbind('<Control_R>')
                self.canvas.unbind(',')
                self.canvas.unbind('.')
                self.canvas.unbind('/')

                self.canvas.unbind('a')
                self.canvas.unbind('d')
                self.canvas.unbind('w')
                self.canvas.unbind('s')
                self.canvas.unbind('<Control_L>')
                self.canvas.unbind('z')
                self.canvas.unbind('x')
                self.canvas.unbind('c')
            self.pause_release = False

    def start_game(self):
        if control_mode == 1:
            self.canvas.unbind('<space>')
            self.canvas.unbind('1')
            self.canvas.unbind('2')
            self.bind()

        self.char = []
        self.char.append(MyChar(self.canvas, self.width / 2 - 50, self.height / 2, 0))
        self.char.append(MyChar(self.canvas, self.width / 2 + 50, self.height / 2, 1))
        self.items[self.char[0].item] = self.char[0]
        self.items[self.char[1].item] = self.char[1]
        
        self.addBrick(57, 236)
        self.addBrick(57, 378)
        self.addBrick(57, 520)

        self.addBrickShadow(150, 236, 0)
        self.addBrickShadow(150, 378, 1)
        self.addBrickShadow(150, 520, 2)

        self.kitchen = []
        self.addKitchen(self.width / 2, 90, 0)
        if self.gamemode: 
            self.addKitchen(self.width / 2, 668, 1)

        self.addCounter(1268, 428)

        self.head1 = MyCharHead(self.canvas, 70, 80, 0)
        if self.gamemode:
            self.head2 = MyCharHead(self.canvas, 70, 670, 1)
            self.score_display1 = self.draw_text(125, 80, ': 0', 35)
            self.score_display2 = self.draw_text(125, 670, ': 0', 35)
        else:
            self.head2 = MyCharHead(self.canvas, 120, 80, 1)
            self.score_display1 = self.draw_text(175,  80, ': 0', 35)

        self.canvas.delete(self.title)
        self.button1.delete(self.canvas)
        self.button2.delete(self.canvas)
        self.canvas.delete(self.text)
        self.start_time = time.time()
        self.accum_time = 0
        self.paused = False
        self.pause_release = True
        self.game_loop()

    def game_loop(self):
        if self.paused:
            remain_time = self.time_limit - int(self.accum_time)
        else:
            remain_time = self.time_limit - int(self.accum_time + time.time() - self.start_time)
        self.update_time_text(remain_time)
        if control_mode == 2: 
            data = self.client.recv(1024).decode('utf-8')
            if len(data) > 5:
                data = data[0:5]
            # print("data =", data)
            if not self.paused: 
                self.char[0].shadow.update_position(data[0], self.items)
                self.char[1].shadow.update_position(data[2], self.items)
            if data[1] == '1':
                self.take_food(0)
                self.use_kitchen(0)
                self.send_meal(0)
            elif data[1] == '0':
                self.stop_using_kitchen(0)
            if data[3] == '1':
                self.take_food(1)
                self.use_kitchen(1)
                self.send_meal(1)
            elif data[3] == '0':
                self.stop_using_kitchen(1)
            if data[4] == '1':
                self.pause()
            elif data[4] == '0':
                self.pause_release = True
        # num_bricks = len(self.canvas.find_withtag('brick'))
        if remain_time <= 0:  # Finish
            for c in self.char:
                c.delete()
            for k in self.kitchen:
                k.delete()
            self.draw_text(self.width / 2, self.height * 0.45, 'Finish!')
            if self.gamemode: 
                if self.score[0] > self.score[1]: 
                    self.draw_text(self.width / 2, self.height * 0.55, 'Player 1 win!')
                elif self.score[1] > self.score[0]: 
                    self.draw_text(self.width / 2, self.height * 0.55, 'Player 2 win!')
                else: 
                    self.draw_text(self.width / 2, self.height * 0.55, 'Tie!')
            else: 
                self.draw_text(self.width / 2, self.height * 0.55, 'Your Score is: ' + str(self.score[0]))
        else:
            self.after(csts.game_loop_delay_time, self.game_loop)  # wait for 50ms, then run game_loop (making a infinite loop)

if __name__ == '__main__':
    game = MyGame()
    game.mainloop()